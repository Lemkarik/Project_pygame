import pygame
import sys
import os
from random import randint, choice
import time

FPS = 50
WIDTH = 500
HEIGHT = 500


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f'Файл с изображением "{fullname}" не найден')
        terminate()
    image = pygame.image.load(fullname)
    return image


def load_sound(name):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f'Файл со звуком "{fullname}" не найден')
        terminate()
    sound = pygame.mixer.Sound(fullname)
    return sound


def load_stat(name):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f'Файл со статистикой "{fullname}" не найден')
        terminate()
    file = open(fullname)
    statistics = file.readlines()
    return statistics


def save_stats(score_record, time_record, total_score, total_time):
    score_record = str(score_record) + '\n'
    time_record = ':'.join([str(time_record // 60), str(time_record % 60)]) + '\n'
    total_score = str(total_score) + '\n'
    total_time = ':'.join([str(total_time // 3600), str(total_time % 3600 // 60),
                           str(total_time % 3600 % 60)]) + '\n'
    fullname = os.path.join('data', 'stat.txt')
    file = open(fullname, 'w')
    file.write(score_record)
    file.write(time_record)
    file.write(total_score)
    file.write(total_time)
    file.close()


screen_rect = (0, 0, 500, 500)


def intro(screen):
    font = pygame.font.Font(None, 100)
    text = font.render('Спасение', True, (255, 255, 255))
    x = -text.get_width() - 5
    clock = pygame.time.Clock()
    show_message = False
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONDOWN:
                return
            if event.type == pygame.KEYDOWN:
                return
        screen.fill((0, 0, 0))
        pygame.draw.rect(screen, (255, 255, 255), (x, 165, text.get_width() + 10,
                                                   text.get_height() + 10), 1)
        screen.blit(text, (x + 5, 170))
        if show_message:
            font2 = pygame.font.Font(None, 20)
            message = font2.render('Нажмите любую кнопку, чтобы продолжить', True, (255, 255, 255),
                                   1)
            screen.blit(message, (90, 270))
            author = font2.render('Автор проекта: Плешивцев Кирилл', True, (255, 255, 255), 1)
            screen.blit(author, (10, 480))
        if x < 70:
            x += 10
        else:
            show_message = True
        clock.tick(FPS)
        pygame.display.flip()


class Particle(pygame.sprite.Sprite):
    fire = [load_image("meteor_piece.png")]
    for scale in (5, 10, 20):
        fire.append(pygame.transform.scale(fire[0], (scale, scale)))

    def __init__(self, pos, dx, dy):
        super().__init__(all_sprites)
        self.image = choice(self.fire)
        self.rect = self.image.get_rect()
        self.dx = dx
        self.dy = dy
        self.rect.x, self.rect.y = pos
        self.gravity = 1

    def update(self):
        self.dy += self.gravity
        self.rect.x += self.dx
        self.rect.y += self.dy
        if not self.rect.colliderect(screen_rect):
            self.kill()


def create_particles(position):
    particle_count = 10
    numbers = range(-3, 3)
    for i in range(particle_count):
        Particle(position, choice(numbers), choice(numbers))


def terminate():
    pygame.quit()
    sys.exit()


def start_screen(width, height, screen):
    background_image = load_image('menu_background.png')
    while True:
        screen.blit(background_image, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 10 <= event.pos[0] <= 130 and 90 <= event.pos[1] <= 130:
                    education(screen)
                    # level(screen)
                if 10 <= event.pos[0] <= 130 and 175 <= event.pos[1] <= 215:
                    stats_screen(screen)
                if 10 <= event.pos[0] <= 130 and 260 <= event.pos[1] <= 280:
                    terminate()
        pygame.draw.rect(screen, (255, 255, 255), (10, 10, 480, 50), 1)
        pygame.draw.rect(screen, (0, 0, 0), (11, 11, 478, 48))
        font1 = pygame.font.Font(None, 50)
        text = font1.render(' ' * 16 + 'Спасение', True, (255, 255, 255), 1)
        screen.blit(text, (15, 15))
        pygame.draw.rect(screen, (255, 255, 255), (10, 90, 120, 40), 1)
        pygame.draw.rect(screen, (0, 0, 0), (11, 91, 118, 38))
        font2 = pygame.font.Font(None, 30)
        start_button = font2.render('Начать', True, (255, 255, 255), 1)
        screen.blit(start_button, (15, 100))
        pygame.draw.rect(screen, (255, 255, 255), (10, 175, 120, 40), 1)
        pygame.draw.rect(screen, (0, 0, 0), (11, 176, 118, 38))
        stat_button = font2.render('Статистика', True, (255, 255, 255), 1)
        screen.blit(stat_button, (15, 185))
        pygame.draw.rect(screen, (255, 255, 255), (10, 260, 120, 40), 1)
        pygame.draw.rect(screen, (0, 0, 0), (11, 261, 118, 38))
        exit_button = font2.render('Выход', True, (255, 255, 255), 1)
        screen.blit(exit_button, (15, 270))
        pygame.display.flip()


def level(screen):
    running = True
    player.rect.x = 210
    player.rect.y = 400
    clock = pygame.time.Clock()
    MYEVENTTYPE = pygame.USEREVENT
    pygame.time.set_timer(MYEVENTTYPE, 10000)
    MYEVENTTYPE2 = pygame.USEREVENT + 1
    pygame.time.set_timer(MYEVENTTYPE2, randint(1, 10) * 1000)
    MYEVENTTYPE3 = pygame.USEREVENT + 2
    pygame.time.set_timer(MYEVENTTYPE3, randint(5, 10) * 1000)
    background = load_image('background.jpg')
    health_image = load_image('heart.png')
    arrows_image = load_image('arrows.png')
    arrows_y = 150
    y1 = 0
    y2 = -background.get_height()
    tardis_speed = 5
    health = 3
    score = 0
    crush_sound = load_sound('crush_sound.wav')
    get_sound = load_sound('get_sound.wav')
    sonic_screwdriver_sound = load_sound('sonic_screwdriver_sound.wav')
    get_sound.set_volume(0.1)
    sonic_screwdriver_sound.set_volume(0.1)
    start = time.time()
    while running:
        screen.fill((0, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                terminate()
            if event.type == MYEVENTTYPE:
                Meteor((randint(0, 400), 0))
                pygame.time.set_timer(MYEVENTTYPE, randint(1, 5) * 1000)
            if event.type == MYEVENTTYPE2:
                Reward((randint(0, 400), 0))
                pygame.time.set_timer(MYEVENTTYPE2, randint(1, 10) * 1000)
            if event.type == MYEVENTTYPE3:
                Repair((randint(0, 400), 0))
        a = pygame.key.get_pressed()
        if a[pygame.K_LEFT] and player.rect.x >= 10:
            player.rect.x -= tardis_speed
        if a[pygame.K_RIGHT] and player.rect.x <= 440:
            player.rect.x += tardis_speed
        if a[pygame.K_DOWN] and player.rect.y <= 420:
            player.rect.y += tardis_speed
        if a[pygame.K_UP] and player.rect.y >= 10:
            player.rect.y -= tardis_speed
        y1 += 1
        y2 += 1
        if y1 > 500:
            y1 = -background.get_height()
        if y2 > 500:
            y2 = -background.get_height()
        if arrows_y < 500:
            arrows_y += 1
        for reward in all_rewards:
            if pygame.sprite.collide_mask(player, reward):
                reward.kill()
                score += 1
                get_sound.play()
        for repair in all_repairs:
            if pygame.sprite.collide_mask(player, repair):
                repair.kill()
                if health < 5:
                    health += 1
                sonic_screwdriver_sound.play()
        for obstacle in all_obstacles:
            if pygame.sprite.collide_mask(player, obstacle):
                create_particles((obstacle.rect.x, obstacle.rect.y))
                obstacle.kill()
                health -= 1
                crush_sound.play()
                if not health:
                    running = False
        screen.blit(background, (0, y1))
        screen.blit(background, (0, y2))
        if arrows_y < 500:
            screen.blit(arrows_image, (190, arrows_y))
        font = pygame.font.Font(None, 50)
        score_view = font.render(str(score), True, (255, 255, 255))
        screen.blit(score_view, (0, 0))
        all_sprites.draw(screen)
        all_sprites.update()
        x = 500 - health_image.get_width()
        for i in range(health):
            screen.blit(health_image, (x, 0))
            x -= health_image.get_width()
        clock.tick(FPS)
        pygame.display.flip()
    finish = time.time()
    spent_time = finish - start
    screen.fill((0, 0, 0))
    end_screen(screen, round(spent_time, 1), score)


def end_screen(screen, spent_time, score):
    spent_time = round(spent_time)
    for i in all_obstacles:
        i.kill()
    for i in all_rewards:
        i.kill()
    for i in all_repairs:
        i.kill()
    statistics = load_stat('stat.txt')
    for ind in range(len(statistics)):
        statistics[ind] = statistics[ind].strip()
    new_score_record = False
    new_time_record = False
    score_record = int(statistics[0])
    time_record = statistics[1].split(':')
    total_score = int(statistics[2])
    total_time = statistics[3].split(':')
    for ind in range(len(time_record)):
        time_record[ind] = int(time_record[ind])
    for ind in range(len(total_time)):
        total_time[ind] = int(total_time[ind])
    time_record = sum(time_record)
    total_time = sum(total_time)
    if score > score_record:
        score_record = score
        new_score_record = True
    if spent_time > time_record:
        time_record = spent_time
        new_time_record = True
    total_time += spent_time
    total_score += score
    save_stats(score_record, time_record, total_score, total_time)
    while True:
        screen.fill((0, 0, 0))
        font1 = pygame.font.Font(None, 90)
        text1 = font1.render('Игра окончена', True, (255, 255, 255))
        screen.blit(text1, (20, 50))
        font2 = pygame.font.Font(None, 60)
        text2 = font2.render(f'Спасено адипоуз: {score}', True, (255, 255, 255))
        screen.blit(text2, (10, 120))
        if spent_time < 60:
            text3 = font2.render(f'Время: {spent_time} сек.', True, (255, 255, 255))
            screen.blit(text3, (10, 170))
        else:
            spent_time = round(spent_time)
            text3 = font2.render(f'Время: {spent_time // 60} мин.', True, (255, 255, 255))
            text4 = font2.render(f'{spent_time % 60} сек.', True, (255, 255, 255))
            screen.blit(text3, (10, 170))
            screen.blit(text4, (170, 220))
        pygame.draw.rect(screen, (255, 255, 255), (10, 280, 120, 50), 1)
        font1 = pygame.font.Font(None, 50)
        text = font1.render('Меню', True, (255, 255, 255), 1)
        screen.blit(text, (15, 285))
        if new_score_record:
            font3 = pygame.font.Font(None, 20)
            message1 = font3.render('Новый рекорд!', True, (0, 255, 0), 1)
            screen.blit(message1, (500 - message1.get_width(), 155))
        if new_time_record:
            font3 = pygame.font.Font(None, 20)
            message2 = font3.render('Новый рекорд!', True, (0, 255, 0), 1)
            if spent_time < 60:
                screen.blit(message2, (500 - message2.get_width(), 205))
            else:
                screen.blit(message2, (500 - message2.get_width(), 255))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if 10 <= event.pos[0] <= 130 and 280 <= event.pos[1] <= 330:
                    start_screen(WIDTH, HEIGHT, screen)
        pygame.display.flip()


def stats_screen(screen):
    statistics = load_stat('stat.txt')
    score_record = statistics[0].strip()
    time_record = statistics[1].strip()
    total_score = statistics[2].strip()
    total_time = statistics[3].strip()
    screen.fill((0, 0, 0))
    font1 = pygame.font.Font(None, 100)
    text = font1.render('Статистика', True, (255, 255, 255))
    screen.blit(text, (50, 10))
    pygame.draw.rect(screen, (255, 255, 255), (5, 5, 480, 70), 1)
    font2 = pygame.font.Font(None, 50)
    score_record_text = font2.render(f'Рекорд баллов: {score_record}', True, (255, 255, 255), 1)
    screen.blit(score_record_text, (10, 90))
    time_record_text = font2.render(f'Рекорд времени: {time_record}', True, (255, 255, 255), 1)
    screen.blit(time_record_text, (10, 130))
    total_record_text = font2.render(f'Всего баллов: {total_score}', True, (255, 255, 255), 1)
    screen.blit(total_record_text, (10, 170))
    total_time_text = font2.render(f'Всего времени: {total_time}', True, (255, 255, 255), 1)
    screen.blit(total_time_text, (10, 210))
    menu_button = font2.render('Меню', True, (255, 255, 255), 1)
    screen.blit(menu_button, (10, 450))
    pygame.draw.rect(screen, (255, 255, 255), (5, 435, 120, 60), 1)
    pygame.display.flip()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if 5 <= event.pos[0] <= 125 and 435 <= event.pos[1] <= 495:
                    start_screen(500, 500, screen)


def education(screen):
    screen.fill((0, 0, 0))
    background = load_image('background.jpg')
    screen.blit(background, (0, 0))
    font1 = pygame.font.Font(None, 80)
    text1 = font1.render('Справка', True, (255, 255, 255))
    alpha_img = pygame.Surface(text1.get_size(), pygame.SRCALPHA)
    alpha_img.fill((255, 255, 255, 255))
    text1.blit(alpha_img, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    screen.blit(text1, (120, 10))
    font2 = pygame.font.Font(None, 25)
    tardis_image = load_image('tardis1.png')
    screen.blit(tardis_image, (10, 60))
    tardis_description_1 = font2.render('ТАРДИС -  лучший космический корабль', True,
                                        (255, 255, 255))
    tardis_description_2 = font2.render('во Вселенной, хотя с первого взгляда', True,
                                        (255, 255, 255))
    tardis_description_3 = font2.render('так и не скажешь. Не повредите её!', True,
                                        (255, 255, 255))
    screen.blit(tardis_description_1, (70, 60))
    screen.blit(tardis_description_2, (70, 90))
    screen.blit(tardis_description_3, (70, 120))
    adipose_image = load_image('adipose.png')
    screen.blit(adipose_image, (10, 150))
    reward_description_1 = font2.render('Адипоуз - раса маленьких существ из жира. Их',
                                        True, (255, 255, 255))
    reward_description_2 = font2.render('корабль-ясли повредился в метеоритном дожде.',
                                        True, (255, 255, 255))
    reward_description_3 = font2.render('Адипоуз совершали плохие поступки, но это не',
                                        True, (255, 255, 255))
    reward_description_4 = font2.render('повод оставлять их в беде! Соберите их', True,
                                        (255, 255, 255))
    reward_description_5 = font2.render('как можно больше!', True, (255, 255, 255))
    screen.blit(reward_description_1, (70, 150))
    screen.blit(reward_description_2, (70, 180))
    screen.blit(reward_description_3, (70, 210))
    screen.blit(reward_description_4, (70, 240))
    screen.blit(reward_description_5, (70, 270))
    sonic_screwdriver_image = load_image('sonic_screwdriver.png')
    screen.blit(sonic_screwdriver_image, (10, 300))
    repair_description_1 = font2.render('Звуковая отвёртка - универсальный инструмент.',
                                        True, (255, 255, 255))
    repair_description_2 = font2.render('Она поможет починить небольшие повреждения',
                                        True, (255, 255, 255))
    repair_description_3 = font2.render('ТАРДИС', True, (255, 255, 255))
    screen.blit(repair_description_1, (70, 300))
    screen.blit(repair_description_2, (70, 330))
    screen.blit(repair_description_3, (70, 360))
    meteor_image = load_image('meteor.png')
    screen.blit(meteor_image, (10, 380))
    meteor_description_1 = font2.render('Астероиды - огромные камни, несущиеся сквозь',
                                        True, (255, 255, 255))
    meteor_description_2 = font2.render('тьму космоса.Они могут поцарапать ТАРДИС,',
                                        True, (255, 255, 255))
    meteor_description_3 = font2.render('так что лучше с ними не сталкиваться',
                                        True, (255, 255, 255))
    screen.blit(meteor_description_1, (70, 390))
    screen.blit(meteor_description_2, (70, 410))
    screen.blit(meteor_description_3, (70, 440))
    pygame.display.flip()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.KEYDOWN:
                level(screen)
            if event.type == pygame.MOUSEBUTTONDOWN:
                level(screen)


class Player(pygame.sprite.Sprite):
    image = load_image('tardis1.png')

    def __init__(self, pos):
        super().__init__(all_sprites)
        self.image = Player.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        pass
        """if not pygame.sprite.collide_mask(self, mountain):
            self.rect = self.rect.move(0, 1)"""


class Meteor(pygame.sprite.Sprite):
    image = load_image('meteor.png')

    def __init__(self, pos):
        super().__init__(all_sprites, all_obstacles)
        self.image = Meteor.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        if not pygame.sprite.collide_mask(self, player):
            self.rect.y += 5
            if self.rect.y > HEIGHT:
                self.kill()


class Reward(pygame.sprite.Sprite):
    image = load_image('adipose.png')

    def __init__(self, pos):
        super().__init__(all_sprites, all_rewards)
        self.image = Reward.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        if not pygame.sprite.collide_mask(self, player):
            self.rect.y += 1
            if self.rect.y > HEIGHT:
                self.kill()


class Repair(pygame.sprite.Sprite):
    image = load_image('sonic_screwdriver.png')

    def __init__(self, pos):
        super().__init__(all_sprites, all_repairs)
        self.image = Repair.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        if not pygame.sprite.collide_mask(self, player):
            self.rect.y += 1
            if self.rect.y > HEIGHT:
                self.kill()


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('Игра')
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    screen.fill((0, 0, 0))
    pygame.display.flip()
    all_sprites = pygame.sprite.Group()
    all_obstacles = pygame.sprite.Group()
    all_rewards = pygame.sprite.Group()
    all_repairs = pygame.sprite.Group()
    player = Player((210, 400))
    intro(screen)
    start_screen(500, 500, screen)
    pygame.quit()
