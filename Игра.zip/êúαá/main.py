import pygame
import sys
import os
from random import randint, choice


FPS = 50


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f'Файл с изображением "{fullname}" не найден')
        terminate()
    image = pygame.image.load(fullname)
    return image


def load_sound(name):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f'Файл со звуком "{fullname}" не найден')
        terminate()
    sound = pygame.mixer.Sound(fullname)
    return sound


screen_rect = (0, 0, 500, 500)


def intro(screen):
    font = pygame.font.Font(None, 100)
    text = font.render('Название', True, (255, 255, 255))
    x = -text.get_width() - 5
    clock = pygame.time.Clock()
    show_message = False
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONDOWN:
                return
            if event.type == pygame.KEYDOWN:
                return
        screen.fill((0, 0, 0))
        pygame.draw.rect(screen, (255, 255, 255), (x, 165, text.get_width() + 10, text.get_height() + 10), 1)
        screen.blit(text, (x + 5, 170))
        if show_message:
            font2 = pygame.font.Font(None, 20)
            message = font2.render('Нажмите любую кнопку, чтобы продолжить', True, (255, 255, 255), 1)
            screen.blit(message, (90, 270))
        if x < 70:
            x += 10
        else:
            show_message = True
        clock.tick(FPS)
        pygame.display.flip()


class Particle(pygame.sprite.Sprite):
    fire = [load_image("meteor_piece.png")]
    for scale in (5, 10, 20):
        fire.append(pygame.transform.scale(fire[0], (scale, scale)))

    def __init__(self, pos, dx, dy):
        super().__init__(all_sprites)
        self.image = choice(self.fire)
        self.rect = self.image.get_rect()
        self.dx = dx
        self.dy = dy
        self.rect.x, self.rect.y = pos
        self.gravity = 1

    def update(self):
        self.dy += self.gravity
        self.rect.x += self.dx
        self.rect.y += self.dy
        if not self.rect.colliderect(screen_rect):
            self.kill()


def create_particles(position):
    particle_count = 10
    numbers = range(-3, 3)
    for i in range(particle_count):
        Particle(position, choice(numbers), choice(numbers))


def terminate():
    pygame.quit()
    sys.exit()


def start_screen(width, height, screen):
    while True:
        screen.fill((0, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 10 <= event.pos[0] <= 110 and 90 <= event.pos[1] <= 130:
                    level(screen)
                if 10 <= event.pos[0] <= 110 and 175 <= event.pos[1] <= 215:
                    terminate()
        pygame.draw.rect(screen, (255, 255, 255), (10, 10, 480, 50), 1)
        font1 = pygame.font.Font(None, 50)
        text = font1.render('Название', True, (255, 255, 255), 1)
        screen.blit(text, (15, 15))
        pygame.draw.rect(screen, (255, 255, 255), (10, 90, 100, 40), 1)
        font2 = pygame.font.Font(None, 30)
        start_button = font2.render('Начать', True, (255, 255, 255), 1)
        screen.blit(start_button, (15, 100))
        pygame.draw.rect(screen, (255, 255, 255), (10, 175, 100, 40), 1)
        text = font2.render('Выход', True, (255, 255, 255), 1)
        screen.blit(text, (15, 185))
        pygame.display.flip()


def level(screen):
    running = True
    player.rect.x = 210
    player.rect.y = 400
    clock = pygame.time.Clock()
    MYEVENTTYPE = pygame.USEREVENT
    pygame.time.set_timer(MYEVENTTYPE, 10000)
    MYEVENTTYPE2 = pygame.USEREVENT + 1
    pygame.time.set_timer(MYEVENTTYPE2, randint(1, 10) * 1000)
    MYEVENTTYPE3 = pygame.USEREVENT + 2
    pygame.time.set_timer(MYEVENTTYPE3, randint(5, 10) * 1000)
    background = load_image('background.jpg')
    health_image = load_image('heart.png')
    y1 = 0
    y2 = -background.get_height()
    tardis_speed = 5
    health = 3
    score = 0
    crush_sound = load_sound('crush_sound.wav')
    get_sound = load_sound('get_sound.wav')
    sonic_screwdriver_sound = load_sound('sonic_screwdriver_sound.wav')
    get_sound.set_volume(0.1)
    sonic_screwdriver_sound.set_volume(0.1)
    while running:
        screen.fill((0, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                terminate()
            if event.type == MYEVENTTYPE:
                Meteor((randint(0, 400), 0))
                pygame.time.set_timer(MYEVENTTYPE, randint(1, 5) * 1000)
            if event.type == MYEVENTTYPE2:
                Reward((randint(0, 400), 0))
                pygame.time.set_timer(MYEVENTTYPE2, randint(1, 10) * 1000)
            if event.type == MYEVENTTYPE3:
                Repair((randint(0, 400), 0))
                print(1)
        a = pygame.key.get_pressed()
        if a[pygame.K_LEFT] and player.rect.x >= 10:
            player.rect.x -= tardis_speed
        if a[pygame.K_RIGHT] and player.rect.x <= 440:
            player.rect.x += tardis_speed
        if a[pygame.K_DOWN] and player.rect.y <= 420:
            player.rect.y += tardis_speed
        if a[pygame.K_UP] and player.rect.y >= 10:
            player.rect.y -= tardis_speed
        y1 += 1
        y2 += 1
        if y1 > 500:
            y1 = -background.get_height()
        if y2 > 500:
            y2 = -background.get_height()
        for reward in all_rewards:
            if pygame.sprite.collide_mask(player, reward):
                reward.kill()
                score += 1
                get_sound.play()
        for repair in all_repairs:
            if pygame.sprite.collide_mask(player, repair):
                repair.kill()
                if health < 5:
                    health += 1
                sonic_screwdriver_sound.play()
        for obstacle in all_obstacles:
            if pygame.sprite.collide_mask(player, obstacle):
                create_particles((obstacle.rect.x, obstacle.rect.y))
                obstacle.kill()
                health -= 1
                crush_sound.play()
                if not health:
                    running = False
        screen.blit(background, (0, y1))
        screen.blit(background, (0, y2))
        font = pygame.font.Font(None, 50)
        score_view = font.render(str(score), True, (255, 255, 255))
        screen.blit(score_view, (0, 0))
        all_sprites.draw(screen)
        all_sprites.update()
        x = 500 - health_image.get_width()
        for i in range(health):
            screen.blit(health_image, (x, 0))
            x -= health_image.get_width()
        clock.tick(FPS)
        pygame.display.flip()
    screen.fill((0, 0, 0))
    end_screen(screen, clock.get_time(), score)


def end_screen(screen, time, score):
    for i in all_obstacles:
        i.kill()
    for i in all_rewards:
        i.kill()
    for i in all_repairs:
        i.kill()
    while True:
        screen.fill((0, 0, 0))
        font1 = pygame.font.Font(None, 90)
        text1 = font1.render('Игра окончена', True, (255, 255, 255))
        screen.blit(text1, (20, 50))
        font2 = pygame.font.Font(None, 60)
        text2 = font2.render(f'Спасено адипоуз: {score}', True, (255, 255, 255))
        screen.blit(text2, (10, 120))
        text3 = font2.render(f'Время: {time}', True, (255, 255, 255))
        screen.blit(text3, (10, 170))
        pygame.draw.rect(screen, (255, 255, 255), (10, 230, 120, 50), 1)
        font1 = pygame.font.Font(None, 50)
        text = font1.render('Меню', True, (255, 255, 255), 1)
        screen.blit(text, (15, 235))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if 10 <= event.pos[0] <= 130 and 230 <= event.pos[1] <= 280:
                    start_screen(500, 500, screen)
        pygame.display.flip()


class Player(pygame.sprite.Sprite):
    image = load_image('tardis1.png')

    def __init__(self, pos):
        super().__init__(all_sprites)
        self.image = Player.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        pass
        """if not pygame.sprite.collide_mask(self, mountain):
            self.rect = self.rect.move(0, 1)"""


class Meteor(pygame.sprite.Sprite):
    image = load_image('meteor.png')

    def __init__(self, pos):
        super().__init__(all_sprites, all_obstacles)
        self.image = Meteor.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        if not pygame.sprite.collide_mask(self, player):
            self.rect.y += 5
            if self.rect.y > 500:
                self.kill()


class Reward(pygame.sprite.Sprite):
    image = load_image('adipose.png')

    def __init__(self, pos):
        super().__init__(all_sprites, all_rewards)
        self.image = Reward.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        if not pygame.sprite.collide_mask(self, player):
            self.rect.y += 1
            if self.rect.y > 500:
                self.kill()


class Repair(pygame.sprite.Sprite):
    image = load_image('sonic_screwdriver.png')

    def __init__(self, pos):
        super().__init__(all_sprites, all_repairs)
        self.image = Repair.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self):
        if not pygame.sprite.collide_mask(self, player):
            self.rect.y += 1
            if self.rect.y > 500:
                self.kill()


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('Игра')
    screen = pygame.display.set_mode((500, 500))
    screen.fill((0, 0, 0))
    pygame.display.flip()
    all_sprites = pygame.sprite.Group()
    all_obstacles = pygame.sprite.Group()
    all_rewards = pygame.sprite.Group()
    all_repairs = pygame.sprite.Group()
    player = Player((210, 400))
    intro(screen)
    start_screen(500, 500, screen)
    pygame.quit()
